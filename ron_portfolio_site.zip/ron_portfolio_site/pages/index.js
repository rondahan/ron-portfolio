import RonPortfolio from '../src/RonPortfolio';

export default function Home() {
  return <RonPortfolio />;
}